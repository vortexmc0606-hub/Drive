STUDIO SWICK - GAS STATION / FREE / VERSION 1.0

22 starter models. The full pack offers 141 models, editable Blender source
and assembled example scenes. A Blender file is not included in this free pack.

Models/FBX and Models/GLB contain individual engine-neutral models.
Textures contains the shared base-color and emission PNG maps.
Documentation contains import, moving-part and modular snapping notes.
Asset_List.txt lists exactly which models are included in this download.
LICENSE.txt permits personal/commercial use and modification, with no attribution
requirement, and prohibits standalone asset-file redistribution/resale.

Use whichever model format suits your project. Keep object hierarchies intact
when you need movable parts. Collision and gameplay code are not supplied.
